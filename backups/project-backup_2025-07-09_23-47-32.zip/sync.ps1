# PowerShell skripta za kompletnu sinhronizaciju sa GitHub-om

Write-Host "🧪 Pokrećem testove pre sinhronizacije..." -ForegroundColor Cyan
& ".\test.ps1"
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Testovi nisu prošli. Sinhronizacija je prekinuta." -ForegroundColor Red
    exit 1
}

Write-Host "🔄 Počinjem sinhronizaciju..."

$pull = git pull origin main
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Greška pri git pull: $pull"
    exit 1
}

Write-Host "📥 Povučene izmene. Dodajem lokalne fajlove..."
git add .

$status = git status --porcelain
if ([string]::IsNullOrWhiteSpace($status)) {
    Write-Host "ℹ️ Nema lokalnih izmena za commit."
    exit 0
}

$msg = Read-Host "✏️ Unesi commit poruku"
Write-Host "📦 Commitujem: '$msg'"
git commit -m "$msg"

Write-Host "🚀 Pushujem na GitHub..."
git push origin main

Write-Host "✅ Sinhronizacija završena uspešno!" 