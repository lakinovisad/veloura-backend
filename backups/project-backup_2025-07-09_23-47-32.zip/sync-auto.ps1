# 🕒 Automatska sinhronizacija - pokretanje u beskonačnoj petlji
# Prekinite sa Ctrl + C

Write-Host "🕒 Automatska sinhronizacija pokrenuta..." -ForegroundColor Green
Write-Host "📝 Skripta će pokretati sync.ps1 svakih 30 minuta" -ForegroundColor Yellow
Write-Host "⏹️  Za prekid pritisnite Ctrl + C" -ForegroundColor Red
Write-Host ""

# Interval u sekundama (30 minuta = 1800 sekundi)
$intervalSeconds = 1800

try {
    while ($true) {
        # Pokretanje sync.ps1
        Write-Host "🔄 Pokretanje sinhronizacije..." -ForegroundColor Cyan
        & .\sync.ps1
        
        # Prikaz vremena sledeće sinhronizacije
        $nextSync = (Get-Date).AddSeconds($intervalSeconds)
        Write-Host "⏰ Sledeća sinhronizacija: $($nextSync.ToString('HH:mm:ss'))" -ForegroundColor Magenta
        Write-Host "💤 Čekanje $($intervalSeconds / 60) minuta..." -ForegroundColor Gray
        Write-Host ""
        
        # Čekanje do sledeće sinhronizacije
        Start-Sleep -Seconds $intervalSeconds
    }
} catch {
    Write-Host ""
    Write-Host "🛑 Automatska sinhronizacija prekinuta." -ForegroundColor Red
    Write-Host "👋 Doviđenja!" -ForegroundColor Green
} 