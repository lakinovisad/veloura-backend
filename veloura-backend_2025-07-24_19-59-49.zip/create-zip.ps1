# PowerShell script to create ZIP archive of the Veloura backend project
# Excludes unnecessary files and folders

$projectName = "veloura-backend"
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$zipFileName = "${projectName}_${timestamp}.zip"
$projectPath = Get-Location

Write-Host "Creating ZIP archive of Veloura backend project..." -ForegroundColor Green
Write-Host "Project path: $projectPath" -ForegroundColor Yellow
Write-Host "ZIP file name: $zipFileName" -ForegroundColor Yellow

# Create temporary directory for files to be zipped
$tempDir = "temp_zip_$(Get-Random)"
New-Item -ItemType Directory -Name $tempDir -Force | Out-Null

try {
    # Copy all files and folders except those we want to exclude
    $excludePatterns = @(
        "node_modules",
        ".git",
        "*.db",
        "temp_*",
        "*.zip",
        "temp_stdout.txt",
        "temp_stderr.txt",
        "backups"
    )
    
    # Get all items in current directory
    $items = Get-ChildItem -Path $projectPath -Force
    
    foreach ($item in $items) {
        $shouldExclude = $false
        
        # Check if item should be excluded
        foreach ($pattern in $excludePatterns) {
            if ($item.Name -like $pattern) {
                $shouldExclude = $true
                break
            }
        }
        
        if (-not $shouldExclude) {
            if ($item.PSIsContainer) {
                # Copy directory
                Copy-Item -Path $item.FullName -Destination "$tempDir\$($item.Name)" -Recurse -Force
                Write-Host "Copied directory: $($item.Name)" -ForegroundColor Cyan
            } else {
                # Copy file
                Copy-Item -Path $item.FullName -Destination "$tempDir\$($item.Name)" -Force
                Write-Host "Copied file: $($item.Name)" -ForegroundColor Cyan
            }
        } else {
            Write-Host "Excluded: $($item.Name)" -ForegroundColor Gray
        }
    }
    
    # Create ZIP archive
    Write-Host "Creating ZIP archive..." -ForegroundColor Green
    Compress-Archive -Path "$tempDir\*" -DestinationPath $zipFileName -Force
    
    # Get file size
    $zipFile = Get-Item $zipFileName
    $fileSize = [math]::Round($zipFile.Length / 1MB, 2)
    
    Write-Host "ZIP archive created successfully!" -ForegroundColor Green
    Write-Host "File: $zipFileName" -ForegroundColor Yellow
    Write-Host "Size: $fileSize MB" -ForegroundColor Yellow
    Write-Host "Location: $($zipFile.FullName)" -ForegroundColor Yellow
    
} catch {
    Write-Host "Error creating ZIP archive: $($_.Exception.Message)" -ForegroundColor Red
} finally {
    # Clean up temporary directory
    if (Test-Path $tempDir) {
        Remove-Item -Path $tempDir -Recurse -Force
        Write-Host "Cleaned up temporary directory" -ForegroundColor Gray
    }
}

Write-Host "`nZIP creation process completed!" -ForegroundColor Green 